#include "Angel.h"
#include <string>

const glm::vec3 WHITE(1.0, 1.0, 1.0);
const glm::vec3 BLACK(0.0, 0.0, 0.0);
const glm::vec3 RED(1.0, 0.0, 0.0);
const glm::vec3 GREEN(0.0, 1.0, 0.0);
const glm::vec3 BLUE(0.0, 0.0, 1.0);

const int TRIANGLE_NUM_POINTS = 3;
const int SQUARE_NUM = 6;
const int SQUARE_NUM_POINTS = 4 * SQUARE_NUM; 
const int CIRCLE_NUM_POINTS = 360;
const int TRAPEZIUM_NUM_POINTS = 4;

// 获得三角形的每个角度
double getTriangleAngle(int point) {
	return 2 * M_PI / 3 * point;
}

// 获得正方形的每个角度
double getSquareAngle(int point) {
	return M_PI / 4 + (M_PI / 2 * point);
}

// 获得圆形的每个角度
double getCircleAngle(int point) {
	return M_PI / 2 + M_PI / 180 * point;
}

// 获得梯形的每个角度
double getTrapeziumAngle(int point) {
	return M_PI / 3 * point;
}

// 生成三角形上的每个点
void generateTrianglePoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex)
{
	// 三角形尺寸
	glm::vec2 scale(0.25, 0.25);
	// 三角形中心位置
	glm::vec2 center(0.0, 0.70);

	// @TODO: 在此函数中修改三角形的顶点位置
	for (int i = 0; i < 3; i++) {
		// 当前顶点对应的角度
		double currentAngle = getTriangleAngle(i);
		// 根据角度及三角形中心计算顶点坐标
		vertices[startVertexIndex + i] = glm::vec2(-sin(currentAngle), cos(currentAngle)) * scale + center;
	}

	// 确定三个顶点的颜色
	colors[startVertexIndex] = RED;
	colors[startVertexIndex + 1] = BLUE;
	colors[startVertexIndex + 2] = GREEN;
}

// 生成正方形上的每个点
void generateSquarePoints(glm::vec2 vertices[], glm::vec3 colors[], int squareNum, int startVertexIndex, glm::vec2 scale = glm::vec2(0.8, 0.8), glm::vec2 center = glm::vec2(0.0, 0.0), glm::vec3 color = glm::vec3({ {0.8F}, {0.5F}, {0.4F} }))
{
	int vertexIndex = startVertexIndex;

	// @TODO: 在此函数中修改，生成多个嵌套正方形
	// 根据正方形及顶点对应角度，计算当前正方形四个顶点坐标
	//float alpha[6];
	//alpha[0] = 1.0, alpha[5] = 0.16666667;
	//for (int i = 4; i >= 1; i--) {
	//	if (i % 2) {
	//		alpha[i] = alpha[i + 1] + 0.16666668;
	//	}
	//	else {
	//		alpha[i] = alpha[i + 1] + 0.16666665;
	//	}
	//	
	//}
	//for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 4; j++)
		{
			double currentAngle = getSquareAngle(j);
			//vertices[vertexIndex] = alpha[i] * glm::vec2(cos(currentAngle), sin(currentAngle)) * scale + center;
			vertices[vertexIndex] = glm::vec2(cos(currentAngle), sin(currentAngle)) * scale + center;
			colors[vertexIndex] = color;
			vertexIndex++;
		}
	//}
}

// 生成圆形的每个点
void generateCirclePoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex)
{
	// 圆形尺寸
	glm::vec2 scale(0.2, 0.2);
	// 圆形中心位置
	glm::vec2 center(0.7, 0.7);

	// @TODO: 在此函数中修改圆形的顶点位置
	for (int i = 0; i < CIRCLE_NUM_POINTS; i++) {
		// 当前顶点对应的角度
		double currentAngle = getCircleAngle(i);
		// 根据角度及圆形中心计算顶点坐标
		vertices[startVertexIndex + i] = glm::vec2(cos(currentAngle), sin(currentAngle)) * scale + center;
		colors[startVertexIndex + i] = glm::vec3({ {0.8F}, {0.4F}, {0.2F} });
	}
}

// 生成梯形每个点
void generateTrapeziumPoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex, glm::vec2 scale = glm::vec2(0.8, 0.8), glm::vec2 center = glm::vec2(0.0, 0.0))
{
	glm::vec3 currentColor[4] = { WHITE, RED, BLUE, GREEN };
	int vertexIndex = startVertexIndex;

	// 根据梯形及顶点对应角度，计算当前梯形四个顶点坐标
	for (int j = 0; j < 4; j++)
	{
		double currentAngle = getTrapeziumAngle(j);
		vertices[vertexIndex] = glm::vec2(cos(currentAngle), sin(currentAngle)) * scale + center;
		if (j == 1 || j == 2) {
			vertices[vertexIndex] *= 0.95;
		}
		//srand((unsigned)time(NULL));
		colors[vertexIndex] = currentColor[rand() % 4];
		vertexIndex++;
	}
}

// 全局变量，两个vao，一个绘制三角形，一个绘制正方形
GLuint vao[7], program;
void solve(int index, glm::vec2* vertices, glm::vec3* colors, int len)
{
	// 创建顶点数组对象
	glGenVertexArrays(1, &vao[index]);		// 分配1个顶点数组对象
	glBindVertexArray(vao[index]);			// 绑定顶点数组对象
	// 创建顶点缓存对象，vbo[2]是因为我们将要使用两个缓存对象，
	// 一个是顶点坐标，一个是顶点颜色
	GLuint vbo[2];

	// 分配1个顶点缓存对象
	glGenBuffers(1, &vbo[0]);
	// 绑定顶点缓存对象
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	// 分配数据所需的存储空间，将数据拷贝到OpenGL服务端内存
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * len, vertices, GL_STATIC_DRAW);
	// 从顶点着色器中初始化顶点的位置
	GLuint location = glGetAttribLocation(program, "vPosition");
	// 启用顶点属性数组
	glEnableVertexAttribArray(location);
	// 关联到顶点属性数组 (index, size, type, normalized, stride, *pointer)
	glVertexAttribPointer(
		location,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec2),
		BUFFER_OFFSET(0));

	// 给颜色
	glGenBuffers(1, &vbo[1]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(colors[0]) * len, colors, GL_STATIC_DRAW);
	GLuint cLocation = glGetAttribLocation(program, "vColor");
	glEnableVertexAttribArray(cLocation);
	glVertexAttribPointer(
		cLocation,
		3,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec3),
		BUFFER_OFFSET(0));
}
void init()
{
	// 读取着色器并使用
	std::string vshader, fshader;
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";
	program = InitShader(vshader.c_str(), fshader.c_str());
	glUseProgram(program);
	// 定义三角形的三个点
	glm::vec2 triangle_vertices[TRIANGLE_NUM_POINTS];
	glm::vec3 triangle_colors[TRIANGLE_NUM_POINTS];
	// 定义矩形的点
	glm::vec2 square_vertices[SQUARE_NUM_POINTS];
	glm::vec3 square_colors[SQUARE_NUM_POINTS];
	// 定义圆形
	glm::vec2 circle_vertices[CIRCLE_NUM_POINTS];
	glm::vec3 circle_colors[CIRCLE_NUM_POINTS];
	// 定义梯形的点
	glm::vec2 trapezium_vertices[TRAPEZIUM_NUM_POINTS];
	glm::vec3 trapezium_colors[TRAPEZIUM_NUM_POINTS];

	// 调用生成形状顶点位置的函数
	//generateTrianglePoints(triangle_vertices, triangle_colors, 0);
	// 太阳
	generateCirclePoints(circle_vertices, circle_colors, 0);
	/*
	* 太阳的数据
	*/
	solve(2, circle_vertices, circle_colors, CIRCLE_NUM_POINTS);
	// 屋主体
	generateSquarePoints(square_vertices, square_colors, SQUARE_NUM, 0, glm::vec2(0.5, 0.35), glm::vec2(-0.15, -0.55));
	/*
	* 房屋主体的数据
	*/
	solve(1, square_vertices, square_colors, SQUARE_NUM_POINTS);
	// 屋顶
	generateTrapeziumPoints(trapezium_vertices, trapezium_colors, 0, glm::vec2(0.55, 0.3), glm::vec2(-0.15, -0.35));
	/*
	* 屋顶的数据
	*/
	solve(3, trapezium_vertices, trapezium_colors, TRAPEZIUM_NUM_POINTS);
	// 草地
	generateSquarePoints(square_vertices, square_colors, SQUARE_NUM, 0, glm::vec2(1.5, 0.5), glm::vec2(0, -0.85), glm::vec3({ {0.2F}, {0.8F}, {0.2F} }));
	/*
	* 草地的数据
	*/
	solve(4, square_vertices, square_colors, SQUARE_NUM_POINTS);
	// 门
	generateSquarePoints(square_vertices, square_colors, SQUARE_NUM, 0, glm::vec2(0.12, 0.2), glm::vec2(-0.32, -0.65), glm::vec3({ {0.0F}, {0.0F}, {0.0F} }));
	/*
	* 门的数据
	*/
	solve(5, square_vertices, square_colors, SQUARE_NUM_POINTS);
	// 窗
	generateSquarePoints(square_vertices, square_colors, SQUARE_NUM, 0, glm::vec2(0.1, 0.1), glm::vec2(0.02, -0.57), glm::vec3({ {0.8F}, {0.8F}, {0.90F} }));
	/*
	* 窗
	*/
	solve(6, square_vertices, square_colors, SQUARE_NUM_POINTS);
	/*
	* 初始化三角形的数据
	*/
	//solve(0, trapezium_vertices, trapezium_colors, TRIANGLE_NUM_POINTS);






	// 黑色背景
	glClearColor(0.3, 0.5, 0.8, 1.0);
}

void display(void)
{
	// 清理窗口
	glClear(GL_COLOR_BUFFER_BIT);

	// 激活着色器
	//glUseProgram(program);
	//// 绑定三角形的顶点数组对象
	//glBindVertexArray(vao[0]);
	//glDrawArrays(GL_TRIANGLES, 0, TRIANGLE_NUM_POINTS);
	// 草地
	glBindVertexArray(vao[4]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	// 屋主体
	glBindVertexArray(vao[1]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

	//// 注意这里使用的绘制模式为GL_TRIANGLE_FAN
	//// 它会以顶点数据的一个点为中心顶点，绘制三角形

	//// 绘制多个正方形
	//for (int i = 0; i < SQUARE_NUM; ++i) {
	//	glDrawArrays(GL_TRIANGLE_FAN, (i * 4), 4);
	//}

	// 太阳
	glBindVertexArray(vao[2]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, CIRCLE_NUM_POINTS);
	// 屋顶
	glBindVertexArray(vao[3]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, TRAPEZIUM_NUM_POINTS);
	// 门
	glBindVertexArray(vao[5]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, TRAPEZIUM_NUM_POINTS);
	// 窗
	glBindVertexArray(vao[6]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, TRAPEZIUM_NUM_POINTS);
	// 强制所有进行中的OpenGL命令完成
	glFlush();
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height);

int main(int argc, char** argv)
{
	// 初始化GLFW库，必须是应用程序调用的第一个GLFW函数
	glfwInit();

	// 配置GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// 配置窗口属性
	GLFWwindow* window = glfwCreateWindow(512, 512, "2022155028_黄亮铭_实验1.2", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// 调用任何OpenGL的函数之前初始化GLAD
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();
	// 指定当前窗口进行重绘时要调用的函数
	while (!glfwWindowShouldClose(window))
	{
		display();

		// 交换颜色缓冲 以及 检查有没有触发什么事件（比如键盘输入、鼠标移动等）
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	return 0;
}

// 每当窗口改变大小，GLFW会调用这个函数并填充相应的参数供你处理。
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}
